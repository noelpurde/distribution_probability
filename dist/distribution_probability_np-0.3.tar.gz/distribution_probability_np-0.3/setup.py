from setuptools import setup, find_packages

setup(
      name='distribution_probability_np',
      version='0.3',
      description='Gaussian and Binomial distributions',
      packages=find_packages(),
      zip_safe=False,
      install_requires=[
          
      ]
)
